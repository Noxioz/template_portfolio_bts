*Login de la plupart des niveaux :* **bandit"NUMERO\_NIVEAU"@bandit.labs.overthewire.org -p 2220**

*MDP bandit0* : **bandit0**





*MDP bandit1* : **6y2kwnwK6grgvwvpvLaa2T1cpFEKOhNR**

Comment trouver : ouvrir le fichier





*MDP bandit2 :* **PK8fYLZg2hnHSz83plBL1iEPKdD3QToB**

Comment trouver : faire "cat ./'NOM\_DU\_FICHIER'" pour forcer l'ouverture du fichier





*MDP bandit3 :* **7ZZ2LFrykP2zEyvBl4m3clcL7tGYJPME**

Comment trouver : faire "cat ./'NOM\_DU\_FICHIER'" avec des guillemets car PowerShell n'aime pas les espaces





*MDP bandit4 :* **xzTXq1rDJQVVAzdv5cHq1TQytTWufAMq**

Comment trouver : juste aller dans le bon répertoire avec "cd", faire un "ls -a", puis "cat"





*MDP bandit5 :* **6C7h9GD8M6ai5nr7wo1RonrzFjj9yIrG**

Comment trouver : aller dans le répertoire, faire "file ./\*" pour trouver le seul fichier ASCII text, et faire "cat ./'NOM\_DU\_FICHIER'"





*MDP bandit6 :* **pXa26xhMWaC2SvDotA4r9EgZkulOeSBW**

Comment trouver : faire "find ./inhere -type f -size 1033c ! -executable" pour trouver le fichier qui correspond aux critères, puis "cat ./'CHEMIN\_D'ACCES\_DU\_FICHIER'"





*MDP bandit7 :* **Bmnnvf82KzQlfxgAI2d1zYbr1u9pr3E3**

Comment trouver : faire "find / -user bandit7 -group bandit6 -size 33c 2>/dev/null" pour trouver le fichier qui correspond aux critères ("2>/dev/null" sert à retirer les erreurs dues à un refus de permission), puis "cat ./'CHEMIN\_D'ACCES\_DU\_FICHIER'"





*MDP bandit8 :* **VR1ljMayciFxbnUokuQmJFw6QC9VKtub**

Comment trouver : faire "grep --word-regexp \*MOT\_A\_TROUVER\* data.txt" pour trouver toutes les lignes avec un mot précis dans le fichier data.txt





*MDP bandit9 :* **EjmOSvuAu7sGAHqHVcBDPirRe9T03kxl**

Comment trouver : faire "sort data.txt | uniq -u" pour trouver la seule ligne unique ("sort" tri les lignes du fichier par ordre alphabétique, "uniq" sert à repérer la ligne unique, et "|" combine les deux)





*MDP bandit10 :* **B0s2khmbT9u0geKuOoVGW3JZKhndE3BG**

Comment trouver : faire "strings data.txt | grep '==='" ("strings" permet de filtrer les parties lisibles pour un humain dans un fichier, transmet le résultat à grep à l'aide du pipe et grep cherche les lignes contenant uniquement les caractères passés en paramètre)





*MDP bandit11 :* **pYfOY6HwUsDj5rL9UvyhU7MCmv8vN5Ro**

Comment trouver : faire "cat data.txt | base64 -d" ("base 64 -d" permet de décoder le fichier ouvert par cat avant le pipe)





*MDP bandit12 :* **GROozWPO8QyN0mGrjUkID0WCYkZiQxrN**

Comment trouver : faire "cat data.txt | tr 'a-zA-Z' 'n-za-mN-ZA-M'" ("tr 'a-zA-Z' 'n-za-mN-ZA-M'" remplace les lettres correspondantes avec un ordre de décalage défini dans les guillemets)





*MDP bandit13 :* **qQYQiHOBPR8zR61qxYqX45quvihF2uzk**

Comment trouver : défi HORRIBLE à base de poupées russes et de plusieurs commandes (toutes les commandes sont en Screenshot dans le dossier "Défi\_Bandit")





*MDP bandit14 :* **aaWecNkG4FhxJQxz07uiwzVP6bJiYS65**

Comment trouver : se log avec bandit13 et télécharger le fichier "sshkey.private" avec une commande "scp". Ensuite delog et relog avec la commande "ssh -i sshkey.private bandit14@bandit.labs.overthewire.org -p 2220". Enfin faire "cat /etc/bandit\_pass/bandit14" et récupérer le mot de passe.





*MDP bandit15 :* **pbLYuZtTg4MgaqfJx8jbA9gKKGqM68A7**

Comment trouver : se connecter à bandit14 et faire "nc localhost 30000"





*MDP bandit16 :* **kS0Hf0u5HiXFwKMKFqXvPdOTNGGa0X8V**

Comment trouver : faire "openssl s\_client -connect localhost:30001" pour créer une connexion chiffrée en SSL puis coller le mot de passe et récupérer le nouveau





*MDP bandit17 :* **pWXMAZoxGC8JmDMfmT5MGEsobMM3vnj2**

Comment trouver : faire le combo de commandes suivant :

&#x20;- faire "mkdir /tmp/ton\_pseudo16" pour créer un dossier de travail temporaire avec un nom un peu random

&#x20;- faire "cd /tmp/ton\_pseudo16" pour se déplacer dans le dossier

&#x20;- faire "nano cle\_bandit17" pour créer un fichier dans le dossier dans lequel on met la clé RSA de bandit17

&#x20;- faire "chmod 600 cle\_bandit17" pour réduire les droits du fichier

&#x20;- créer une nouvelle fenêtre vierge dans le terminal

&#x20;- faire "scp -P 2220 bandit16@bandit.labs.overthewire.org:/tmp/ton\_pseudo16/cle\_bandit17" pour télécharger la clé depuis la page vierge

&#x20;- faire "ssh -i C:\\TON\\CHEMIN\\D'ACCES\\VERS\\cle\_bandit17 -p 2220 bandit17@bandit.labs.overthewire.org" pour se connecter (faire glisser le fichier directement dans le terminal si la commande ne marche pas avec le nom simplement)

&#x20;- enfin faire "cat /etc/bandit\_pass/bandit17" pour récupérer le mot de passe de bandit17





*MDP bandit18 :* **OQxXZjELndr90zuhOTDYBEomI0SZITXI**

Comment trouver : faire "diff passwords.new passwords.old"





*MDP bandit19 :* **KpsOfPkcP7i1FlIExk2QEjyt6dw8dxZI**

Comment trouver : faire "ssh bandit18@bandit.labs.overthewire.org -p 2220 ls" pour voir les fichiers présents ans le répertoire perso, puis "ssh bandit18@bandit.labs.overthewire.org -p 2220 cat readme" pour lire le fichier





*MDP bandit20 :* **4pIjcunZ0fK2vmp3IwfG8Vf7VhxD6pOA**

Comment trouver : faire "./bandit20-do whoami" pour éxécuter le fichier, puis faire "./bandit20-do cat /etc/bandit\_pass/bandit20" pour lire le fichier et récupérer le mot de passe





*MDP bandit21 :* **bW9kBv5WC3P4yoDyf12LSdGuNz5ka6hY**

Comment trouver : faire "echo 4pIjcunZ0fK2vmp3IwfG8Vf7VhxD6pOA | nc -l -p 45678 \&" pour se connecter sur au serveur sur un port choisi puis faire "./suconnect 45678" pour comparer les mots de passe et récupérer le nouveau





*MDP bandit22 :* **RYVux2rHEm9tiXHmLFzuR7Vhx6AZQMEz**

Comment trouver : faire le combo de commande suivant :

&#x20;- faire "cd /etc/cron.d/" pour se déplacer dans le bon répertoire

&#x20;- faire "cat cronjob\_bandit22" pour avoir le chemin d'accès vers "/usr/bin/cronjob\_bandit22.sh"

&#x20;- faire "cat /usr/bin/cronjob\_bandit22.sh" pour avoir le fichier /tmp à exécuter

&#x20;- faire "cat /tmp/t7O6lds9S0RqQh9aMcz6ShpAoZKF7fgv" (remplacer le nom du fichier si il a changé) pour que le terminal retourne le nouveau mot de passe





*MDP bandit23 :* **gKXDTAXnIz3OBxiPjRZ2uqutUlPZrBsw**

Comment trouver : faire le combo de commandes suivant :

&#x20;- faire "cd /etc/cron.d/" pour se déplacer dans le bon répertoire

&#x20;- faire "cat cronjob\_bandit23" pour avoir le chemin d'accès vers /usr/bin/cronjob\_bandit23.sh

&#x20;- faire "cat /usr/bin/cronjob\_bandit23.sh" pour avoir le fichier /tmp à exécuter

&#x20;- faire "echo I am user bandit23 | md5sum | cut -d ' ' -f 1" pour avoir le nom du fichier à ouvrir 

&#x20;- faire "cat /tmp/LA\_CHAINE\_DE\_CARACTERES\_COPIEE" (remplacer par la chaine de caractères) pour que le terminal retourne le nouveau mot de passe





*MDP bandit24 :* **hVQMk3lJNsmQ7VF3ubyrNNBom7BOgVXv**

Comment trouver : faire le combo de commandes suivant :

&#x20;- faire "cat /etc/cron.d/cronjob\_bandit24" pour se déplacer dans le bon répertoire

&#x20;- faire "cat /usr/bin/cronjob\_bandit24.sh" pour avoir le fichier /tmp à exécuter

&#x20;- faire "mkdir /tmp/mon\_dossier23er23" pour créer un dossier de travail temporaire

&#x20;- faire "cd /tmp/mon\_dossier23" pour se déplacer dans le répertoire temporaire

&#x20;- faire "chmod 777 /tmp/mon\_dossier23" pour donner les permissions complètes au dossier crée

&#x20;- faire "echo "cat /etc/bandit\_pass/bandit24 > /tmp/mon\_dossier23/motdepasse.txt" >> script.sh" pour créer un fichier avec la commande pour lire le mot de passe et l'envoyer dans le dossier temporaire

&#x20;- faire "chmod +x script.sh" pour rendre le script exécutable pour que cron puisse le lancer

&#x20;- faire "cp script.sh /var/spool/bandit24/foo/" pour copier le script vers le fichier ciblé par cron

&#x20;- faire "cat /tmp/mon\_dossier23/motdepasse.txt" pour ouvrir le fichier et récupérer le nouveau mot de passe





*MDP bandit25 :* **SoHfqMOEqIX2IYKVciZxvgpR9a2Djx4P**

Comment trouver : faire le combo de commandes suivant :

&#x20;- faire "mkdir /tmp/bf\_bandit24" pour créer un dossier temporaire

&#x20;- faire "cd /tmp/bf\_bandit24" pour se déplacer dans le dossier temporaire

&#x20;- faire "for i in {0000..9999}; do echo "hVQMk3lJNsmQ7VF3ubyrNNBom7BOgVXv $i"; done > dico.txt" pour créer un dictionnaire avec tous les codes PIN de 0000 à 9999 avec le mot de passe de bandit24

&#x20;- faire "cat dico.txt | nc localhost 30002 | grep -v "Wrong" " pour injecter le dictionnaire dans le port 30002 (grep -v "Wrong" permet de ne pas afficher les erreurs)





*MDP bandit26 :* **jHdv2ELQhT22BkprMNDjybZDAkw1zeBJ**

Comment trouver : faire le combo de commandes suivant (ATTENTION : à faire absolument dans cmd car PowerShell fait bugger le niveau) :

&#x20;- faire "cd $env:USERPROFILE\\Desktop" pour se déplacer dans un dossier avec les droits d'écriture sur le pc (en l'occurrence le bureau)

&#x20;- faire "scp -P 2220 bandit25@bandit.labs.overthewire.org:\~/bandit26.sshkey ." pour télécharger le fichier avec la clé RSA de bandit26

&#x20;- se delog et se placer dans le répertoire avec la clé RSA (copier le chemin d'accès si besoin depuis l'explorateur de fichiers)

&#x20;- faire "icacls bandit26.sshkey /inheritance:r" puis "icacls bandit26.sshkey /grant:r "%username%":"(R)"" pour réduire les droits du fichier et le passer en lecture uniquement

&#x20;- IMPORTANT !! : réduire la fenêtre du terminal au minimum pour bypass la déco automatique

&#x20;- faire "ssh -i bandit26.sshkey bandit26@bandit.labs.overthewire.org -p 2220" pour se connecter à bandit26 sans mettre de mot de passe

&#x20;- faire "vi" quand il affiche "--More--" pour ouvrir VIM

&#x20;- une fois un "--More--" en vert fluo affiché, faire ":set shell=/bin/bash" puis ":sh" pour forcer l'ouverture d'un vrai shell interactif et bypass le faux shell avec auto-delog

&#x20;- si le terminal affiche "bandit26@bandit:\~$", c'est good, donc faire un "whoami" pour vérifier la présence du fichier bandit26

&#x20;- enfin faire "cat /etc/bandit\_pass/bandit26" pour ouvrir le fichier et récupérer le mot de passe





*MDP bandit27 :* **STJLJBRRphMxKB392CT4iOr5CbzPU9ER**

Comment trouver : faut rester sur la session bandit26 et faire "./bandit27-do cat /etc/bandit\_pass/bandit27"

ATTENTION : En cas de déco automatique pour inactivité, voici la démarche à suivre :

&#x20;- se placer dans le répertoire avec la clé RSA (copier le chemin d'accès si besoin depuis l'explorateur de fichiers)

&#x20;- faire "ssh -i bandit26.sshkey bandit26@bandit.labs.overthewire.org -p 2220" pour se connecter à bandit26 sans mettre de mot de passe

&#x20;- faire "vi" quand il affiche "--More--" pour ouvrir VIM

IMPORTANT !! : si une fois un "--More--" en vert fluo affiché et si le terminal affiche un gros logo bandit26 avec une mention "INSERT" en bas en gauche, vous êtes dans le mode insertion de VIM. Appuyez simplement sur Echap pour revenir en arrière et exécuter les commandes suivantes

&#x20;- faire ":set shell=/bin/bash" puis ":sh" pour forcer l'ouverture d'un vrai shell interactif et bypass le faux shell avec auto-delog

&#x20;- une fois que le terminal affiche "bandit26@bandit:\~$", faire "ls -la" puis "./bandit27-do cat /etc/bandit\_pass/bandit27" pour ouvrir le fichier et enfin récupérer le mot de passe de bandit27





*MDP bandit28 :* **y8Yd2ssKcpHpud7UvOSOxwamRMzIGIeQ**

Comment trouver : installer Git et faire les commandes suivantes :

&#x20;- installer Git avec "winget install --id Git.Git -e --source winget"

&#x20;- se déplacer dans un dossier dans lequel on possède les droits de modification (ici le dossier "Défi\_Bandit")

&#x20;- cloner le dépôt qui nous intéresse avec "git clone ssh://bandit27-git@bandit.labs.overthewire.org:2220/home/bandit27-git/repo"

&#x20;- faire "cd repo" puis "type README" pour ouvrir le fichier avec le mot de passe (ou juste aller dans le répertoire et l'ouvrir avec Bloc-notes)





*MDP bandit29 :* **Em7eGtqaMySwNFjCpwzzHhLhospOcdt0**

Comment trouver : faire le combo de commandes suivant :

&#x20;- faire "git clone ssh://bandit28-git@bandit.labs.overthewire.org:2220/home/bandit28-git/repo repo28" pour cloner le dépôt (le repo28 sert à renommer le nouveau fichier pour le différencier de l'ancien

&#x20;- faire "cd repo28" puis "type README" pour ouvrir le fichier avec le mot de passe --> on se retrouve avec des X

&#x20;- faire "git log -p" pour accéder à l'historique des mises à jour et récupérer le mot de passe le plus récent





*MDP bandit30 :* **jq9Dfg2rXsfYsWMgFuKlXhphjdH7USgX**

Comment trouver : faire le combo de commandes suivant :

&#x20;- faire "git clone ssh://bandit29-git@bandit.labs.overthewire.org:2220/home/bandit29-git/repo repo29" pour cloner le dépôt

&#x20;- faire "git log -p" pour accéder à l'historique des mises à jour

&#x20;- faire "git branch -a" pour accéder aux différentes branches du dépôt

&#x20;- faire "git checkout dev" pour basculer le fichier en dev

&#x20;- faire "type README.md" pour ouvrir le fichier et récupérer le mot de passe





*MDP bandit31 :* **82NkymblpGBYmIXG6ZQ8YldBYstHpfUf**

Comment trouver : faire le combo de commandes suivant :

&#x20;- faire "git clone ssh://bandit30-git@bandit.labs.overthewire.org:2220/home/bandit30-git/repo repo30" pour cloner le dépôt

&#x20;- faire "git tag" pour afficher les tag disponibles

&#x20;- faire git show "NOM\_DU\_TAG" pour voir le vrai message et récupérer le mot de passe





*MDP bandit32 :* **pWuj5jBQ6IgV0NXwiH6g1pXRF8S1YvbT**

Comment trouver : faire le combo de commandes suivant :

&#x20;- faire "git clone ssh://bandit31-git@bandit.labs.overthewire.org:2220/home/bandit31-git/repo repo31" pour cloner le dépôt

&#x20;- faire "Set-Content -Path key.txt -Value 'May I come in?' -Encoding Ascii" pour écraser le fichier avec le bon encodage et avoir un encodage ASCII

&#x20;- faire "git add -f key.txt" pour forcer l'ajout à Git

&#x20;- faire "git commit --amend --no-edit" pour écrase le commit précédent avec le nouveau fichier

&#x20;- faire "git push origin master" pour revoyer le fichier au serveur (le mot de passe sera renvoyé au passage dans une des lignes "remote")





*MDP bandit33 :* **u4P2CyPOwPGLe94RdD9Uo2FxFwvnFswM**

Comment trouver : se log au bandit32 et faire "$0" pour ouvrir un terminal sans shift lock activé et faire "cat /etc/bandit\_pass/bandit33" pour récupérer le mot de passe



