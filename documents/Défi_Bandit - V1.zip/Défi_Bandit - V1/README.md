#### Ce dossier contient tous les éléments nécessaires à la résolution des 33 niveaux du jeu Bandit, disponible sur le site Internet OverTheWire à l'adresse : https://overthewire.org/wargames/bandit/



##### Dans ce dossier, vous trouverez :



* ###### un fichier Markdown "Infos Bandit - OverTheWire.md" avec toutes les solutions des niveaux et toutes les commandes nécessaires



* ###### une capture d'écran "Commandes poupées russes bandit 12.png" avec les commandes à utiliser pour le niveau 12



* ###### un fichier "sshkey.private" avec la clé RSA pour le niveau 14



* ###### un fichier "cle\_bandit17" avec la clé RSA  pour le niveau 17



* ###### un fichier "bandit26.sshkey" avec la clé RSA pour le niveau 26



* ###### 5 dossiers renommés "repo", "repo28", "repo29", "repo30", "repo31" qui sont des clonages de dépôts Git et qui contiennent chacun un fichier "README.txt" avec des indices pour les niveaux 27 à 31

